DROP TABLE IF EXISTS `#__roksprocket_items`;

DROP TABLE IF EXISTS `#__roksprocket`;